import java.util.Scanner;

public class Problem2Method2
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int y,m,d;
        boolean run;
        System.out.print("请输入年份:");
        y=sc.nextInt();
        System.out.print("请输入月份:");
        m=sc.nextInt();
        if(y%4==0&&y%100!=0||y%400==0) run=true;
        else run=false;
        d=switch(m)
        {
            case 1,3,5,7,8,10,12->31;
            case 2->
            {
                if(run) yield 29;
                else yield 28;
            }
            case 4,6,9,11->30;
            default->0;
        };
        System.out.print(y+"年"+m+"月份有"+d+"天。");
    }
}