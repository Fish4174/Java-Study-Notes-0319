public class Problem3
{
    public static void main(String[] args)
    {
        var isPrime=new boolean[1005];
        for(int i=0;i<1005;i++) isPrime[i]=true;
        int cnt=0,sum=0;
        isPrime[0]=isPrime[1]=false;
        for(int i=2;i*i<=1000;i++)
        {
            if(isPrime[i])
            {
                for(int j=i*i;j<=1000;j+=i)
                {
                    isPrime[j]=false;
                }
            }
        }
        System.out.println("1-1000中的素数有：");
        for(int i=1;i<=1000;i++)
        {
            if(isPrime[i])
            {
                System.out.print(i+" ");
                cnt++;
                if(cnt%10==0) System.out.println();
                sum+=i;
            }
        }
        System.out.println();
        System.out.println("共有"+cnt+"个，和为"+sum);
    }
}
