import java.util.*;
public class Problem4
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        Random rand=new Random();
        int magic=rand.nextInt(30)+1;
        int in,cnt=1;
        System.out.println("随机生成了一个1~30之间整数，请你来猜猜它");
        in=sc.nextInt();
        while(true)
        {
            if(in==magic)
            {
                System.out.println("恭喜，答对！");
                break;
            }
            else if(in<magic)
            {
                System.out.println("很遗憾，您猜小了！");
            }
            else if(in>magic)
            {
                System.out.println("很遗憾，您猜大了！");
            }
            cnt++;
            if(cnt>5)
            {
                System.out.println("失败，游戏结束！这个数是"+magic);
            }
            in=sc.nextInt();
        }
    }
}
