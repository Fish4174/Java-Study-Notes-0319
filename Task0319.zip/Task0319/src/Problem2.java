import java.util.Scanner;

public class Problem2
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int y,m;
        boolean run;
        System.out.print("请输入年份:");
        y=sc.nextInt();
        System.out.print("请输入月份:");
        m=sc.nextInt();
        if(y%4==0&&y%100!=0||y%400==0) run=true;
        else run=false;
        System.out.print(y+"年"+m+"月份有");
        switch(m)
        {
            case 1,3,5,7,8,10,12-> System.out.print("31");
            case 2->
            {
                if(run) System.out.print("29");
                else System.out.print("28");
            }
            case 4,6,9,11-> System.out.print("30");
        }
        System.out.println("天。");
    }
}