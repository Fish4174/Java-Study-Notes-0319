import java.util.Scanner;

public class Problem1
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        double a,b,c,p,s;
        System.out.println("请输入三角形的三边长");
        a=sc.nextDouble();
        b=sc.nextDouble();
        c=sc.nextDouble();
        if(a+b<=c||a+c<=b||b+c<=a)
        {
            System.out.println("无法构成三角形，请输入合理参数！");
        }
        else
        {
            p=(a+b+c)/2.0;
            s=Math.sqrt(p*(p-a)*(p-b)*(p-c));
            System.out.println("三角形的面积为"+s);
        }
    }
}
